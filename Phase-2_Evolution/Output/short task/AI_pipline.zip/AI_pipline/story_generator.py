# story_generator.py
import os
import requests
from dotenv import load_dotenv

load_dotenv()

OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY")
if not OPENROUTER_API_KEY:
    raise RuntimeError("OPENROUTER_API_KEY not found in .env file")

MODEL = "anthropic/claude-3-sonnet"
API_URL = "https://openrouter.ai/api/v1/chat/completions"

HEADERS = {
    "Authorization": f"Bearer {OPENROUTER_API_KEY}",
    "HTTP-Referer": "http://localhost",
    "X-Title": "AI Creative Pipeline",
    "Content-Type": "application/json",
}


def generate_story(expanded_prompt: str) -> str | None:
    """Generate a short, imaginative story (3–5 sentences) inspired by the image description."""
    print("\n[3/3] Writing creative story...")

    messages = [
        {
            "role": "system",
            "content": "You are a creative storyteller who writes vivid, emotional short stories based on visual prompts.",
        },
        {
            "role": "user",
            "content": (
                f"Write a short, imaginative 3–5 sentence story inspired by this image description:\n\n"
                f"{expanded_prompt}\n\n"
                f"The story should be descriptive and reflect the atmosphere and emotions of the scene."
            ),
        },
    ]

    payload = {"model": MODEL, "messages": messages, "temperature": 0.9}

    try:
        response = requests.post(
            API_URL, headers=HEADERS, json=payload, timeout=60)
        response.raise_for_status()
    except requests.exceptions.RequestException as e:
        print(f"❌ Story generation failed: {e}")
        return None

    try:
        data = response.json()
        if "choices" in data and len(data["choices"]) > 0:
            story = data["choices"][0]["message"]["content"].strip()
            print("\n✅ Story generated successfully!\n")
            return story
        else:
            print("⚠️ Unexpected response format:", data)
            return None
    except Exception as e:
        print("❌ Failed to parse story:", e)
        return None
