# text_generator.py
import os
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY")
if not OPENROUTER_API_KEY:
    raise RuntimeError("OPENROUTER_API_KEY not found in .env file")

client = OpenAI(
    base_url="https://openrouter.ai/api/v1",
    api_key=OPENROUTER_API_KEY,
)


def expand_prompt(prompt: str) -> str | None:
    """Expand a short idea into a vivid, creative description using OpenRouter."""
    print(f"[1/3] Expanding text prompt using google/gemini-2.5-pro...")

    try:
        completion = client.chat.completions.create(
            model="google/gemini-2.5-pro",
            messages=[
                {"role": "system", "content": "You are a creative AI assistant that expands short ideas into vivid, detailed prompts for image generation."},
                {"role": "user", "content": f"Expand this idea into a single, vivid, creative sentence for AI image generation:\n{prompt}"}
            ],
            extra_headers={
                "HTTP-Referer": "http://localhost",
                "X-Title": "AI Creative Pipeline",
            },
            temperature=0.8
        )

        expanded = completion.choices[0].message.content.strip()

        print("\n💡 Expanded prompt (shown to user):")
        print(expanded, "\n")

        return expanded

    except Exception as e:
        print("❌ Text generation failed:", e)
        return None
