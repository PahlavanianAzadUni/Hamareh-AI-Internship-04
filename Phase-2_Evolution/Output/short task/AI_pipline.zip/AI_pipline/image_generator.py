# image_generator.py
import os
import requests
import base64
from dotenv import load_dotenv

load_dotenv()

STABILITY_API_KEY = os.getenv("STABILITY_API_KEY")
if not STABILITY_API_KEY:
    raise RuntimeError("STABILITY_API_KEY not found in .env file")

MODEL = "stable-diffusion-xl-1024-v1-0"
API_URL = f"https://api.stability.ai/v1/generation/{MODEL}/text-to-image"


def generate_image(prompt: str, output_path: str = "outputs/generated_image.png") -> str | None:
    """Generate an image from text using Stability.ai API."""
    headers = {
        "Authorization": f"Bearer {STABILITY_API_KEY}",
        "Content-Type": "application/json",
        "Accept": "application/json",
    }

    payload = {
        "text_prompts": [{"text": prompt}],
        "cfg_scale": 7,
        "height": 1024,
        "width": 1024,
        "samples": 1,
        "steps": 30,
    }

    try:
        print(f"[2/3] Generating image using {MODEL}...")
        response = requests.post(
            API_URL, headers=headers, json=payload, timeout=90)
        response.raise_for_status()
    except requests.exceptions.HTTPError as e:
        print(f"HTTP error: {e} — {response.text}")
        return None
    except requests.exceptions.RequestException as e:
        print("Request failed:", e)
        return None

    try:
        data = response.json()
        if "artifacts" not in data or not data["artifacts"]:
            print("No image found in response:", data)
            return None

        image_base64 = data["artifacts"][0]["base64"]
        image_bytes = base64.b64decode(image_base64)

        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
        with open(output_path, "wb") as f:
            f.write(image_bytes)

        print(f"Image saved at: {output_path}")
        return output_path
    except Exception as e:
        print("Failed to parse image:", e)
        return None
