# main.py
import os
from dotenv import load_dotenv
from openai import OpenAI
from image_generator import generate_image

load_dotenv()

OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY")
if not OPENROUTER_API_KEY:
    raise RuntimeError("❌ OPENROUTER_API_KEY not found in .env file")

client = OpenAI(
    base_url="https://openrouter.ai/api/v1",
    api_key=OPENROUTER_API_KEY,
)


def generate_text(prompt: str) -> str | None:
    """Generate an expanded prompt and a creative story using Gemini 2.5 Pro via OpenRouter."""
    print("[1/2] Generating expanded prompt and story using Gemini 2.5 Pro...")

    try:
        completion = client.chat.completions.create(
            model="google/gemini-2.5-pro",
            messages=[
                {
                    "role": "system",
                    "content": (
                        "You are a creative AI that expands short human ideas "
                        "into detailed image prompts and short 3–5 sentence stories."
                    ),
                },
                {
                    "role": "user",
                    "content": (
                        f"Expand this idea into a detailed image-generation prompt, "
                        f"and then write a 3–5 sentence creative story inspired by it:\n\n{prompt}"
                    ),
                },
            ],
            temperature=0.9,
            extra_headers={
                "HTTP-Referer": "http://localhost",
                "X-Title": "AI Creative Pipeline",
            },
        )

        message = completion.choices[0].message
        if hasattr(message, "content") and message.content:
            result = message.content.strip()
        else:
            print("⚠️ Unexpected response format:", completion)
            return None

        print("✅ Text generated successfully!")
        return result

    except Exception as e:
        print("❌ Text generation failed:", e)
        return None


def make_output_folder(user_prompt: str) -> str:
    """Create a folder in outputs/ named exactly as the user prompt, handling illegal characters."""
    illegal_chars = ['<', '>', ':', '"', '/', '\\', '|', '?', '*']
    folder_name = ''.join(
        '_' if c in illegal_chars else c for c in user_prompt)

    folder_path = os.path.join("outputs", folder_name)
    os.makedirs(folder_path, exist_ok=True)
    return folder_path


def main():
    print("✨ AI Creative Pipeline (Gemini + Stability.ai)")
    print("--------------------------------------------------")

    user_input = input("Enter a short concept or idea: ").strip()
    if not user_input:
        print("⚠️ No input provided.")
        return

    # 1️⃣ Create a folder inside outputs/ named after user prompt
    output_folder = make_output_folder(user_input)

    # 2️⃣ Generate text
    text_output = generate_text(user_input)
    if not text_output:
        print("❌ Text generation failed.")
        return

    # 3️⃣ Generate image
    print("[2/2] Generating image using Stability.ai...")
    image_path = os.path.join(output_folder, "generated_image.png")
    image_result = generate_image(user_input, image_path)

    if not image_result:
        print("❌ Image generation failed.")
        return

    # 4️⃣ Save text and story
    text_path = os.path.join(output_folder, "story.txt")
    with open(text_path, "w", encoding="utf-8") as f:
        f.write(text_output)

    print("\n✅ DONE!")
    print("----------------------------")
    print(f" Original idea: {user_input}")
    print(f" Text & Story saved to: {text_path}")
    print(f" Image saved to: {image_path}")
    print("----------------------------")


if __name__ == "__main__":
    main()
